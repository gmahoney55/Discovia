﻿var apiAddress = 'http://localhost:50308/api/';
var controllerNameUser = 'user/';
var controllerNameClient = 'client/'
var controllerNameMatter = 'matter/'
var controllerNameUserMatter = 'UserMatter/'
//var baseAddress = 'http://localhost:50308/api/user/';
var baseAddress = apiAddress + controllerNameUser;
var baseAddressClientController = apiAddress + controllerNameClient;
var baseAddressMatterController = apiAddress + controllerNameMatter;
var baseAddressUserMatterController = apiAddress + controllerNameUserMatter;
var url = "";

partnerViewApp.config(['$routeProvider',
           function ($routeProvider) {
               $routeProvider.
                  when('/profile', {
                      templateUrl: 'profile.html',
                      controller: 'profileController'
                  }).
                  when('/editProfile', {
                      templateUrl: 'editprofile.html',
                      controller: 'editProfileController'
                  }).

                    when('/accountSetUp', {
                        templateUrl: 'manageUsers.html',
                        controller: 'manageUsersController'
                    }).
                    when('/setUpProfile', {
                        templateUrl: 'setUpProfile.html',
                        controller: 'setUpProfileController'
                    }).
                   when('/matter', {
                       templateUrl: 'matter.html',
                       controller: 'matterController'
                   }).
                  otherwise({
                      redirectTo: '/matter'
                      //redirectTo: '/profile'
                  });
           }]);

partnerViewApp.factory('partnerViewAppFactory', function ($http, $cookieStore) {
    return {
        loginUser: function (user) {
            url = baseAddress + "LoginUser";
            return $http.post(url, user);
        },
        SetPasswordToken: function (user) {
            url = baseAddress + "SetPasswordToken";
            return $http.post(url, user);
        },
        setUpProfile: function (user) {
            url = baseAddress + "SetUpProfile";
            return $http.put(url, user);
        },
        AuthenticateLoginToken: function () {
            if (token[1] != null) {
                url = baseAddress + "AuthenticateLoginToken/" + token[1];
            }
            else {
                window.location = "login.html";
            }
            return $http.get(url);
        },
        AuthenticateToken: function () {
            url = baseAddress + "AuthenticateToken/" + arr[1];
            return $http.get(url);
        },
        ChangePassword: function (user) {
            url = baseAddress + "ChangePassword";
            return $http.post(url, user);
        },
        getUser: function () {
            var id = localStorage.getItem('userId');
            url = baseAddress + "GetUser/" + id;
            return $http.get(url);
        },
        updateUser: function (user) {
            url = baseAddress + "ModifyUser";
            return $http.put(url, user);
        },
        SetPasswordToken: function (user) {
            url = baseAddress + "SetPasswordToken/" + user.userName;
            return $http.get(url);
        },
        getUsersList: function () {
            url = baseAddress + "GetUsersList";
            return $http.get(url);
        },
        addUser: function (user) {
            url = baseAddress + "AddUser";
            return $http.post(url, user);
        },
        deleteUser: function (user) {
            url = baseAddress + "DeleteUser/" + user.userID;
            return $http.delete(url);
        },
        updateUser: function (user) {
            url = baseAddress + "ModifyUser/" + user.userID;
            return $http.put(url, user);
        },
        getMatters: function () {
            var userName = localStorage.getItem('userName');
            url = baseAddressMatterController + "GetMatters/" + userName;
            return $http.get(url);
        },
        getUserMatters: function () {
            var userName = localStorage.getItem('matterUserName');
            url = baseAddressMatterController + "GetMatters/" + userName;
            return $http.get(url);
        },

        addUserMatter: function (matter) {
            url = baseAddressUserMatterController + "AddMatter";
            return $http.post(url, matter);
        }
    };

});


//let's make a startFrom filter for paging purpose
partnerViewApp.filter('offset', function () {
    return function (input, start) {
        start = parseInt(start, 10);
        return input.slice(start);
    }
});