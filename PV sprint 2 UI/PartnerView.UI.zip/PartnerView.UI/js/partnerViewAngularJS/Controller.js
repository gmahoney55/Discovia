﻿partnerViewApp.controller('loginController', function PostController($http, $scope, partnerViewAppFactory) {
    $http.defaults.headers.common.Authorization = "loginToken";
    $scope.users = [];
    $scope.user = null;
    $scope.editMode = false;
    $scope.errormessage = false;

    //Login User
    $scope.get = function () {
        var currentUser = this.user;
        var currentUser = this.user;

        if (currentUser != null && currentUser.password != null && currentUser.userName) {

            partnerViewAppFactory.loginUser(currentUser).success(function (data) {
                if (data.name != null) {
                    localStorage.setItem('name', data.name);
                    localStorage.setItem('userId', data.userID);
                    localStorage.setItem('userName', data.userName);
                    localStorage.setItem('userRole', data.userRole);
                    localStorage.setItem('loginToken', data.loginToken);
                    window.location = "index.html";
                }
                else {
                    $scope.errormessage = true;
                    $scope.error = "Invalid username/ password!";
                }
                // $scope.user = data;
            }).error(function (data, status) {
                alert('error');
                $scope.error = "An Error has occured while Loading users! " + data.ExceptionMessage;
            });
        };
    }

});

partnerViewApp.controller('forgotPasswordController', function PostController($http, $scope, partnerViewAppFactory) {
    $http.defaults.headers.common.Authorization = "forgotPasswordToken";
    $scope.users = [];
    $scope.user = null;
    $scope.editMode = false;
    $scope.successmessage = false;

    //get Password
    $scope.getPassword = function () {
        var currentUser = this.user;
        if (currentUser.userName != null) {
            partnerViewAppFactory.SetPasswordToken(currentUser).success(function (data) {
                if (data == "true") {
                    $scope.successmessage = true;
                    $scope.errormessage = false;
                    $scope.error = "Check the email account associated with your user name for instructions on resetting your password. Remember to look in your spam folder, where automated messages sometimes filter. If you still can't log in, contact your administrator.";
                }
                else {
                    $scope.errormessage = true;
                    $scope.successmessage = false;
                    $scope.error = "Please verify that you are entering the correct username.";
                }
                // $scope.user = data;
            }).error(function (data, status) {
                $scope.errormessage = true;
                $scope.successmessage = false;
                $scope.error = "An Error has occured! " + data.ExceptionMessage;
            });
        };
    }
});

partnerViewApp.controller('setUpProfileController', function PostController($http, $scope, $cookieStore, partnerViewAppFactory, $location) {
    $http.defaults.headers.common.Authorization = "AccountSetUpToken";
    $scope.users = [];
    $scope.editMode = true;

    if (token[1] == null) {
        window.location = "login.html";
    }
    else {
        $scope.user = null;
        localStorage.clear();
    }

    //get AuthenticateToken
    $scope.AuthenticateLoginToken = function () {
        partnerViewAppFactory.AuthenticateLoginToken().success(function (data) {
            if (data == null) {
                window.location = "login.html";
            }
            else {
                localStorage.setItem('userId', data.userID);
                localStorage.setItem('userRole', data.userRole);
                $scope.user = data;
            }
            // $scope.user = data;
        }).error(function (data, status) {
            $scope.error = "An Error has occured!";
        });
    };

    //update user
    $scope.setUpProfile = function () {
        var currentUser = this.user;
        if (token[1] != null) {
            currentUser.loginToken = token[1];
        }
        if (currentUser != null && currentUser.name != null && currentUser.userName && currentUser.mobile && currentUser.password) {
            partnerViewAppFactory.setUpProfile(currentUser).success(function (data) {
                localStorage.setItem('userId', data.userID);
                localStorage.setItem('userRole', data.userRole);
                localStorage.setItem('loginToken', data.loginToken);
                localStorage.setItem('name', data.name);
                window.location = "index.html";
                currentUser.editMode = false;

            }).error(function (data) {
                $scope.error = "An Error has occured!";
            });
        }
        else {
            $scope.error = "You can't left any field blank.";
        }
    }

});

partnerViewApp.controller('profileController', function PostController($http, $scope, partnerViewAppFactory) {

    $http.defaults.headers.common.Authorization = localStorage.getItem('loginToken');
    $scope.users = [];
    $scope.user = null;
    $scope.editMode = false;
    var id = localStorage.getItem('userId');
    if (id == null) {
        window.location = "login.html";
    }
    //get User
    $scope.get = function () {
        partnerViewAppFactory.getUser().success(function (data) {
            $scope.user = data;
            localStorage.setItem('user', JSON.stringify($scope.user));
        }).error(function (data, status) {
            $scope.error = "An Error has occured!";
        });
    };
});

partnerViewApp.controller('editProfileController', function PostController($http, $scope, partnerViewAppFactory, $location) {
    //edit user
    $http.defaults.headers.common.Authorization = localStorage.getItem('loginToken');
    var id = localStorage.getItem('userId');
    if (id == null) {
        window.location = "login.html";
    }
    $scope.users = [];
    $scope.user = JSON.parse(localStorage.getItem('user'))
    $scope.editMode = true;


    //update user
    $scope.update = function () {
        var currentUser = this.user;
        currentUser.adminUserID = localStorage.getItem('userId');
        if (currentUser != null && currentUser.name != null && currentUser.userName && currentUser.mobile) {
            partnerViewAppFactory.updateUser(currentUser).success(function (data) {
                currentUser.editMode = false;
                $location.path("/profile");
                $('#userModel').modal('hide');
            }).error(function (data) {
                $scope.error = "An Error has occured!";
            });
        }
        else {
            $scope.error = "You can't left any field blank.";
        }
    }

    $scope.cancel = function () {
        $location.path("/profile");
    };

    //get Password
    $scope.resetPassword = function () {
        var currentUser = this.user;
        partnerViewAppFactory.SetPasswordToken(currentUser).success(function (data) {
            alert("Password has been reset successfully! You will now logout from here. Check the email account associated with your user name for instructions on resetting your password.");

            localStorage.clear();
            $scope.user = null;
            window.location = "login.html";
            // $scope.user = data;
        }).error(function (data, status) {
            $scope.error = "An Error has occured!";
        });
    }
});

partnerViewApp.controller('manageUsersController', function PostController($http, $scope, partnerViewAppFactory) {
    $http.defaults.headers.common.Authorization = localStorage.getItem('loginToken');
    $scope.users = [];
    $scope.user = null;
    $scope.editMode = false;
    $scope.truefalse = false;

    $scope.itemsPerPage = 5;
    $scope.currentPage = 0;





    var userRole = localStorage.getItem('userRole');
    if (userRole != "admin") {
        window.location = "login.html";
    }

    var id = localStorage.getItem('userId');
    if (id == null) {
        window.location = "login.html";
    }

    //get User
    $scope.getUserData = function () {
        $scope.user = this.user;
        $('#viewModal').modal('show');
    };


    //get all Users
    $scope.getAll = function () {
        partnerViewAppFactory.getUsersList().success(function (data) {
            $scope.users = data;

        }).error(function (data, status) {
            $scope.error = "An Error has occured! ";
        });
    };




    $scope.range = function () {
        var rangeSize = 3;
        //if ($scope.users.length < 4) {
        //     rangeSize = 0;
        //}
        //else {
        //     rangeSize = 3;
        //}
        var ret = [];
        var start;

        start = $scope.currentPage;
        if (start > $scope.pageCount() - rangeSize) {
            start = $scope.pageCount() - rangeSize + 1;
        }

        for (var i = start; i < start + rangeSize; i++) {
            if (i >= 0)
                ret.push(i);
        }
        return ret;
    };

    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };

    $scope.prevPageDisabled = function () {
        return $scope.currentPage === 0 ? "hide" : "";
    };

    $scope.pageCount = function () {
        return Math.ceil($scope.users.length / $scope.itemsPerPage) - 1;
    };

    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pageCount()) {
            $scope.currentPage++;
        }
    };

    $scope.nextPageDisabled = function () {
        return $scope.currentPage === $scope.pageCount() ? "hide" : "";
    };

    $scope.setPage = function (n) {
        $scope.currentPage = n;
    };

    // add User
    $scope.add = function () {
        var currentUser = this.user;
        currentUser.adminUserID = localStorage.getItem('userId');

        if (currentUser != null && currentUser.name != null && currentUser.userName && currentUser.mobile) {
            partnerViewAppFactory.addUser(currentUser).success(function (data) {
                if (data == "Success") {
                    $scope.addMode = false;
                    $scope.users.push(currentUser);
                    $scope.user = null;
                    $('#userModel').modal('hide');
                    alert("User added successfully.");
                }
                else {
                    alert(data);
                }
            }).error(function (data) {
                $scope.error = "An Error has occured while Adding user! " + data.ExceptionMessage;
            });
        }
    };

    //edit user
    $scope.edit = function () {
        $scope.user = this.user;
        $scope.editMode = true;
        $scope.truefalse = true;
        $('#userModel').modal('show');
    };

    //update user
    $scope.update = function () {
        var currentUser = this.user;
        currentUser.adminUserID = localStorage.getItem('userId');
        currentUser.userRole = localStorage.getItem('userRole');
        partnerViewAppFactory.updateUser(currentUser).success(function (data) {
            if (data == "Success") {
                currentUser.editMode = false;
                $('#userModel').modal('hide');
                alert("User updated successfully.");
            }
            else {
                alert(data);
            }

        }).error(function (data) {
            $scope.error = "An Error has occured while Updating user! " + data.ExceptionMessage;
        });
    };

    // delete User
    $scope.delete = function () {
        currentUser = $scope.user;
        partnerViewAppFactory.deleteUser(currentUser).success(function (data) {
            if (data == true) {
                $('#confirmModal').modal('hide');
                $scope.users.pop(currentUser);
                $scope.getAll();
                alert("User deleted successfully.");
            }

        }).error(function (data) {
            $scope.error = "An Error has occured while Deleting user! " + data.ExceptionMessage;

            $('#confirmModal').modal('hide');
        });
    };

    //Model popup events
    $scope.showadd = function () {
        $scope.truefalse = false;
        $scope.user = null;
        $scope.editMode = false;
        $('#userModel').modal('show');
    };

    $scope.showedit = function () {
        $('#userModel').modal('show');
    };

    $scope.showconfirm = function (data) {
        $scope.user = data;
        $('#confirmModal').modal('show');
    };

    $scope.cancel = function () {
        $scope.user = null;
        $('#userModel').modal('hide');
        $('#userMatterModel').modal('hide');
        $scope.getAll();
    }

    $scope.matters = [];
    $scope.matter = null;
    $scope.innerMatter = null;
    $scope.selectedMatter = [];

   

    // method to get selected user matters
    $scope.getUserMatter = function (id) {
        $scope.matters = [];
        //$scope.getMatters();
        $scope.user = this.user;
        partnerViewAppFactory.getMatters().success(function (data) {
            $scope.matters = data;
            localStorage.setItem('matterUserName', $scope.user.userName);
            partnerViewAppFactory.getUserMatters().success(function (data) {
                angular.forEach($scope.matters, function (matter) {
                    angular.forEach(data, function (innerMatter) {
                        if (innerMatter.MatterId == matter.MatterId) {
                            matter.selected = true;
                        }
                    });
                });
            }).error(function (data, status) {
                $scope.error = "An Error has occured!";
            });
            localStorage.setItem('matterUserId', $scope.user.userID);
            $('#userMatterModel').modal('show');
        }).error(function (data, status) {
            $scope.error = "An Error has occured!";
        });
    };



    // to assign the matters to the user
    $scope.addUserMatter = function () {
        $scope.selectedMatter = [];
        angular.forEach($scope.matters, function (matter) {
            if (matter.selected) {
                matter.UserId = localStorage.getItem('matterUserId');
                if (matter.MatterId != null && matter.UserId != null) {
                    $scope.selectedMatter.push(matter);
                }
            }
        });
        partnerViewAppFactory.addUserMatter($scope.selectedMatter).success(function (data) {
            if (data == "Success") {
                alert("Matters assigned to the user successfully.")
            }
        }).error(function (data) {
            $scope.error = "An Error has occured while assigning user matters: " + data.ExceptionMessage;
        });
    }

    $scope.cancelMatterModel = function () {
        $scope.user = null;
        $('#userMatterModel').modal('hide');
    }

    // initialize your users data
    $scope.getAll();

});

partnerViewApp.controller('indexController', function PostController($http, $scope, partnerViewAppFactory) {
    $http.defaults.headers.common.Authorization = localStorage.getItem('loginToken');
    var userRole = localStorage.getItem('userRole');
    if (userRole == "admin") {
        $scope.hidemanageAccount = false;
    }
    else {
        $scope.hidemanageAccount = true;
    }
    $scope.welcomeMessage = localStorage.getItem('name');

    $scope.logOut = function () {
        $scope.user = null;
        localStorage.clear();
        window.location = "login.html";
    };

    $scope.menuMatterclass = "active";
    $scope.changeProfileclass = function () {
        $scope.menuProfileclass = "active";
        $scope.menuAccountSetUpclass = "";
        $scope.menuMatterclass = "";
    };
    $scope.changeAccountSetUpclass = function () {
        $scope.menuProfileclass = "";
        $scope.menuMatterclass = "";
        $scope.menuAccountSetUpclass = "active";
    };
    $scope.changeMatterclass = function () {
        $scope.menuProfileclass = "";
        $scope.menuAccountSetUpclass = "";
        $scope.menuMatterclass = "active";
    };
});

partnerViewApp.controller('resetPasswordController', function PostController($http, $scope, partnerViewAppFactory) {
    $http.defaults.headers.common.Authorization = "resetPasswordToken";
    $scope.users = [];
    $scope.user = null;
    $scope.editMode = false;

    //get AuthenticateToken
    $scope.getPassword = function () {
        partnerViewAppFactory.AuthenticateToken().success(function (data) {
            if (data == "true") {
                $scope.errormessage = false;
                $scope.successmessage = true;
            }
            else {
                $scope.errormessage = true;
                $scope.successmessage = false;
                $scope.error = "This password reset link is expired. Please re-submit your reset request from the sign-in page.";
            }
            // $scope.user = data;
        }).error(function (data, status) {
            $scope.pageerrormessage = true;
            $scope.error = "An Error has occured!";
        });
    };

    //get ResetPassword
    $scope.ChangePassword = function () {
        if ($scope.user.password.length < 6 || $scope.user.confirmPassword.length < 6) {
            $scope.pageerrormessage = true;
            $scope.error = "Password must contain at least six characters!";
            return false;
        }
        if ($scope.user.password != $scope.user.confirmPassword) {
            $scope.pageerrormessage = true;
            $scope.error = "Password not matched!";
            return false;
        }

        var currentUser = this.user;
        currentUser.passwordToken = arr[1];
        partnerViewAppFactory.ChangePassword(currentUser).success(function (data) {
            if (data == "true") {
                $scope.success = true;
                $scope.pageerrormessage = false;
                $scope.false = false;
                $scope.successmessage = false;
            }
            else {
                $scope.pageerrormessage = true;
                $scope.error = "An Error has occured! Please contact your administrator.";
            }
            // $scope.user = data;
        }).error(function (data, status) {
            $scope.pageerrormessage = true;
            $scope.error = "An Error has occured! ";
        });
    };

});

partnerViewApp.controller('matterController', function PostController($http, $scope, partnerViewAppFactory) {

    $http.defaults.headers.common.Authorization = localStorage.getItem('loginToken');
    $scope.matters = [];
    $scope.matter = null;
    var id = localStorage.getItem('userId');
    if (id == null) {
        window.location = "login.html";
    }

    //get matter data
    $scope.getMatterData = function () {
        $scope.matter = this.matter;
        $('#viewModal').modal('show');
    };

    //get  all Matters
    $scope.getMatters = function () {
        partnerViewAppFactory.getMatters().success(function (data) {
            $scope.matters = data;
        }).error(function (data, status) {
            $scope.error = "An Error has occured!";
        });
    };
    $scope.getMatters();


    //$scope.getUserMatter = function (id) {
    //    alert($scope.matter)
    //    partnerViewAppFactory.getMatters().success(function (data) {
    //        $scope.matter = [{ name: data.Name, id: data.MatterId, UserId: id, isChecked: false }];
    //    }).error(function (data, status) {
    //        $scope.error = "An Error has occured!";
    //    });


    //    localStorage.setItem('UserId', id);
    //    $('#userMatterModel').modal('show');
    //};

    //$scope.addUserMatter = function () {
    //    angular.forEach($scope.matters, function (matter) {
    //        if (matter.selected) {
    //            matter.UserId = localStorage.getItem('UserId');
    //            if (matter.MatterId != null && matter.UserId != null) {
    //                partnerViewAppFactory.addUserMatter(matter).success(function (data) {
    //                    if (data == "Success") {
    //                        $scope.matters.push(matter);
    //                        $scope.matters = null;
    //                    }
    //                }).error(function (data) {
    //                    $scope.error = "An Error has occured while Adding user matter! " + data.ExceptionMessage;
    //                });
    //            }
    //        }
    //    });
    //}
});